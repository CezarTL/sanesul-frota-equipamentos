// firebase-config.js
// Paste your firebaseConfig values (already provided)
export const firebaseConfig = {
  apiKey: "AIzaSyDF_Cv8YIEpQ8b7CJnWTI9NQfGGnJUHLcg",
  authDomain: "sanesul-frota.firebaseapp.com",
  projectId: "sanesul-frota",
  storageBucket: "sanesul-frota.firebasestorage.app",
  messagingSenderId: "580100534932",
  appId: "1:580100534932:web:6c3249bd75bafbbd59ba81",
  measurementId: "G-ENXW03KNSX"
};
